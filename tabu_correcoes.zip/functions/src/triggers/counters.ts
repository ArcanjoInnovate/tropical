// functions/src/counters.ts
//
// Cloud Functions para gerenciamento seguro de contadores.
// Estes contadores NÃO podem ser escritos pelo cliente (rules: ".write": false).
// Apenas estas CFs atualizam via admin SDK (bypass rules).
//
// Contadores gerenciados:
//   - Users/{uid}/followers_count
//   - Users/{uid}/following_count
//   - Users/{uid}/unreadNotificationsCount
//   - Users/{uid}/unreadChatsCount
//   - Users/{uid}/chatTabBadge
//   - Users/{uid}/report_count
//   - Festas/{id}/interessados
//   - Festas/{id}/confirmados
//   - Festas/{id}/comment_count

import { getDatabase, ServerValue } from "firebase-admin/database";
import {
  onValueCreated,
  onValueDeleted,
  onValueWritten,
} from "firebase-functions/v2/database";

const db = getDatabase();
const REGION = "us-central1";

// ══════════════════════════════════════════════════════════════════════════════
//  FOLLOWERS COUNT — incremento/decremento atômico
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Trigger: quando alguém começa a seguir.
 * Caminho: Users/{uid}/followers/{followerUid} = true
 */
export const onFollowerAdded = onValueCreated(
  { ref: "Users/{uid}/followers/{followerUid}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const uid = event.params.uid;
    await db.ref(`Users/${uid}/followers_count`).set(
      ServerValue.increment(1)
    );
  }
);

/**
 * Trigger: quando alguém deixa de seguir.
 * Caminho: Users/{uid}/followers/{followerUid} deletado
 */
export const onFollowerRemoved = onValueDeleted(
  { ref: "Users/{uid}/followers/{followerUid}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const uid = event.params.uid;
    const countRef = db.ref(`Users/${uid}/followers_count`);
    await countRef.transaction((current: number | null) => {
      if (current === null || current <= 0) return 0;
      return current - 1;
    });
  }
);

/**
 * Trigger: quando o próprio usuário segue alguém.
 * Caminho: Users/{uid}/following/{targetUid} = true
 */
export const onFollowingAdded = onValueCreated(
  { ref: "Users/{uid}/following/{targetUid}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const uid = event.params.uid;
    await db.ref(`Users/${uid}/following_count`).set(
      ServerValue.increment(1)
    );
  }
);

/**
 * Trigger: quando o próprio usuário deixa de seguir.
 */
export const onFollowingRemoved = onValueDeleted(
  { ref: "Users/{uid}/following/{targetUid}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const uid = event.params.uid;
    const countRef = db.ref(`Users/${uid}/following_count`);
    await countRef.transaction((current: number | null) => {
      if (current === null || current <= 0) return 0;
      return current - 1;
    });
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  REPORT COUNT — incremento atômico ao criar denúncia
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Trigger: quando uma denúncia de usuário é criada.
 * Incrementa report_count no perfil do denunciado.
 */
export const onUserReportCreated = onValueCreated(
  { ref: "Reports/users/{reportId}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const data = event.data.val() as Record<string, unknown> | null;
    if (!data) return;

    const reportedUid = data.reported_user_id as string | undefined;
    if (!reportedUid) return;

    await db.ref(`Users/${reportedUid}/report_count`).set(
      ServerValue.increment(1)
    );
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  NOTIFICATION BADGE — incremento/decremento atômico
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Trigger: nova notificação criada.
 * Se 'read' === false, incrementa unreadNotificationsCount.
 */
export const onNotificationCreated = onValueCreated(
  { ref: "Notifications/{uid}/{notifId}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const uid  = event.params.uid;
    const data = event.data.val() as Record<string, unknown> | null;
    if (!data) return;

    // Só incrementa se a notificação é não-lida
    if (data.read !== true) {
      await db.ref(`Users/${uid}/unreadNotificationsCount`).set(
        ServerValue.increment(1)
      );
    }
  }
);

/**
 * Trigger: notificação atualizada (ex: marcada como lida).
 */
export const onNotificationUpdated = onValueWritten(
  { ref: "Notifications/{uid}/{notifId}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const uid = event.params.uid;
    const before = event.data.before.val() as Record<string, unknown> | null;
    const after  = event.data.after.val()  as Record<string, unknown> | null;

    // Se foi deletada
    if (!after && before && before.read !== true) {
      const ref = db.ref(`Users/${uid}/unreadNotificationsCount`);
      await ref.transaction((c: number | null) => (c && c > 0) ? c - 1 : 0);
      return;
    }

    // Se foi marcada como lida
    if (before && after && before.read !== true && after.read === true) {
      const ref = db.ref(`Users/${uid}/unreadNotificationsCount`);
      await ref.transaction((c: number | null) => (c && c > 0) ? c - 1 : 0);
    }
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  FESTAS — CONTADORES DE PRESENÇA
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Trigger: presença de usuário em festa alterada.
 * Recalcula contadores de interessados/confirmados.
 */
export const onFestaPresencaChanged = onValueWritten(
  { ref: "Festas/{festaId}/presenca/{uid}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const festaId = event.params.festaId;
    const before  = event.data.before.val() as string | null;
    const after   = event.data.after.val()  as string | null;

    const updates: Record<string, unknown> = {};

    // Decrementa o anterior
    if (before === "interessado") {
      updates[`Festas/${festaId}/interessados`] = ServerValue.increment(-1);
    } else if (before === "confirmado") {
      updates[`Festas/${festaId}/confirmados`] = ServerValue.increment(-1);
    }

    // Incrementa o novo
    if (after === "interessado") {
      updates[`Festas/${festaId}/interessados`] = ServerValue.increment(1);
    } else if (after === "confirmado") {
      updates[`Festas/${festaId}/confirmados`] = ServerValue.increment(1);
    }

    if (Object.keys(updates).length > 0) {
      await db.ref().update(updates);
    }
  }
);

/**
 * Trigger: comentário adicionado em festa.
 */
export const onFestaCommentAdded = onValueCreated(
  { ref: "Festas/{festaId}/comentarios/{commentId}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const festaId = event.params.festaId;
    await db.ref(`Festas/${festaId}/comment_count`).set(
      ServerValue.increment(1)
    );
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  POST LIKES — decremento ao descurtir
//
//  O incremento fica em notificacoes.ts (notificarNovaCurtida → onValueCreated).
//  Aqui só o decremento, que não tem notificação associada.
// ══════════════════════════════════════════════════════════════════════════════

export const onLikeRemoved = onValueDeleted(
  { ref: "PostLikes/{postId}/{likerUid}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const { postId } = event.params;
    const countRef = db.ref(`Posts/post/${postId}/likes`);
    await countRef.transaction((current: number | null) => {
      if (current === null || current <= 0) return 0;
      return current - 1;
    });
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  COMMENTS — decremento ao deletar comentário
//
//  O incremento fica em notificacoes.ts (notificarNovoComentario → onValueCreated).
//  Aqui só o decremento, que não tem notificação associada.
// ══════════════════════════════════════════════════════════════════════════════

export const onCommentRemoved = onValueDeleted(
  { ref: "Comments/{postId}/{commentId}", region: REGION, instance: "tabuapp-4325a-default-rtdb" },
  async (event) => {
    const { postId } = event.params;
    const countRef = db.ref(`Posts/post/${postId}/comment_count`);
    await countRef.transaction((current: number | null) => {
      if (current === null || current <= 0) return 0;
      return current - 1;
    });
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  CHAT BADGE — REMOVIDO
//  O trigger updateChatTabBadgeOnMessage em chat.ts já escuta este mesmo path
//  (Chats/{chatId}/unreadCount/{uid}) e faz recalcChatTabBadge completo.
//  Manter dois triggers no mesmo path causava execução duplicada e custos extras.
// ══════════════════════════════════════════════════════════════════════════════