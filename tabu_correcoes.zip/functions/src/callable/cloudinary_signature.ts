// src/cloudinary_signature.ts

import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret }       from "firebase-functions/params";

const cloudinaryApiSecret = defineSecret("CLOUDINARY_API_SECRET");
const cloudinaryApiKey    = defineSecret("CLOUDINARY_API_KEY");

export const getUploadSignature = onCall(
  {
    region:          "us-central1",
    secrets:         [cloudinaryApiSecret, cloudinaryApiKey],
    // TODO: reativar quando App Check for implementado no cliente
    // enforceAppCheck: true,
  },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Login necessário");
    }

    const timestamp = Math.round(Date.now() / 1000);
    const folder    = `users/${request.auth.uid}`;

    const crypto = await import("crypto");
    const toSign = `folder=${folder}&timestamp=${timestamp}${cloudinaryApiSecret.value()}`;
    const signature = crypto
      .createHash("sha1")
      .update(toSign)
      .digest("hex");

    return {
      timestamp,
      signature,
      folder,
      apiKey: cloudinaryApiKey.value(),
    };
  }
);