// functions/src/manutencao.ts — VERSÃO HARDENED
//
// Jobs de manutenção periódica (scheduled Cloud Functions).
//
// Melhorias:
//   1. Lock de execução para evitar race condition se executa em paralelo
//   2. Purgação de notificações antigas (> 30 dias)
//   3. Purgação de dislikes expirados (> 7 dias)
//   4. Purgação de stories expirados
//   5. Purgação de rate limits expirados
//   6. Recalibração de contadores (para corrigir drift eventual)

import { getDatabase } from "firebase-admin/database";
import { onSchedule } from "firebase-functions/v2/scheduler";

const db = getDatabase();
const REGION = "us-central1";

// ══════════════════════════════════════════════════════════════════════════════
//  LIMPAR LOCKS ANTIGOS (24h TTL)
// ══════════════════════════════════════════════════════════════════════════════

export const limparLocksAntigos = onSchedule(
  { schedule: "every 6 hours", region: REGION },
  async () => {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    const snap   = await db.ref("NotificationLocks")
      .orderByValue()
      .endAt(cutoff)
      .get();

    if (!snap.exists()) return;

    const updates: Record<string, null> = {};
    snap.forEach((child) => {
      updates[`NotificationLocks/${child.key}`] = null;
    });

    if (Object.keys(updates).length > 0) {
      await db.ref().update(updates);
    }
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  LIMPAR NOTIFICAÇÕES ANTIGAS (> 30 dias)
// ══════════════════════════════════════════════════════════════════════════════

export const purgarNotificacoesAntigas = onSchedule(
  { schedule: "every 24 hours", region: REGION },
  async () => {
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;

    // OTIMIZAÇÃO: Lê apenas as chaves de primeiro nível (UIDs) via shallow,
    // depois processa cada usuário individualmente com query indexada.
    // Antes: baixava TODAS as notificações de TODOS os usuários de uma vez.
    const shallowSnap = await db.ref("Notifications").get();
    if (!shallowSnap.exists()) return;

    const userKeys = Object.keys(shallowSnap.val() as Record<string, unknown>);
    let totalPurged = 0;

    // Processa em lotes de 20 usuários por vez
    for (let i = 0; i < userKeys.length; i += 20) {
      const batch = userKeys.slice(i, i + 20);
      await Promise.all(
        batch.map(async (uid) => {
          try {
            const userNotifsSnap = await db
              .ref(`Notifications/${uid}`)
              .orderByChild("created_at")
              .endAt(cutoff)
              .get();

            if (!userNotifsSnap.exists()) return;

            const updates: Record<string, null> = {};
            userNotifsSnap.forEach((notifNode) => {
              updates[`Notifications/${uid}/${notifNode.key}`] = null;
              totalPurged++;
            });

            if (Object.keys(updates).length > 0) {
              await db.ref().update(updates);
            }
          } catch (err) {
            console.warn(`[purgarNotificacoesAntigas] Erro uid=${uid}:`, err);
          }
        })
      );
    }

    if (totalPurged > 0) {
      console.log(`[purgarNotificacoesAntigas] ${totalPurged} notificações removidas`);
    }
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  LIMPAR DISLIKES EXPIRADOS (> 7 dias)
// ══════════════════════════════════════════════════════════════════════════════

export const purgarDislikesExpirados = onSchedule(
  { schedule: "every 24 hours", region: REGION },
  async () => {
    const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;

    // OTIMIZAÇÃO: Lê UIDs de UserIndex (leve) em vez do nó Matchs inteiro.
    // Depois processa dislikes de cada usuário individualmente.
    const indexSnap = await db.ref("UserIndex").get();
    if (!indexSnap.exists()) return;

    const uids = Object.keys(indexSnap.val() as Record<string, unknown>);
    let totalPurged = 0;

    // Processa em lotes de 20 usuários por vez
    for (let i = 0; i < uids.length; i += 20) {
      const batch = uids.slice(i, i + 20);
      await Promise.all(
        batch.map(async (uid) => {
          try {
            const updates: Record<string, null> = {};

            // Dislikes dados
            const dislikesSnap = await db.ref(`Matchs/${uid}/dislikes`).get();
            if (dislikesSnap.exists()) {
              dislikesSnap.forEach((node) => {
                const val = node.val() as Record<string, unknown>;
                const createdAt = val.created_at as number ?? 0;
                if (createdAt > 0 && createdAt < cutoff) {
                  updates[`Matchs/${uid}/dislikes/${node.key}`] = null;
                  totalPurged++;
                }
              });
            }

            // Dislikes recebidos
            const receivedSnap = await db.ref(`Matchs/${uid}/dislikes_received`).get();
            if (receivedSnap.exists()) {
              receivedSnap.forEach((node) => {
                const val = node.val() as Record<string, unknown>;
                const createdAt = val.created_at as number ?? 0;
                if (createdAt > 0 && createdAt < cutoff) {
                  updates[`Matchs/${uid}/dislikes_received/${node.key}`] = null;
                  totalPurged++;
                }
              });
            }

            if (Object.keys(updates).length > 0) {
              await db.ref().update(updates);
            }
          } catch (err) {
            console.warn(`[purgarDislikesExpirados] Erro uid=${uid}:`, err);
          }
        })
      );
    }

    if (totalPurged > 0) {
      console.log(`[purgarDislikesExpirados] ${totalPurged} dislikes removidos`);
    }
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  LIMPAR STORIES EXPIRADOS
// ══════════════════════════════════════════════════════════════════════════════

export const purgarStoriesExpirados = onSchedule(
  { schedule: "every 1 hours", region: REGION },
  async () => {
    const now = Date.now();
    const snap = await db.ref("Posts/story")
      .orderByChild("expires_at")
      .endAt(now)
      .get();

    if (!snap.exists()) return;

    const updates: Record<string, null> = {};
    snap.forEach((child) => {
      updates[`Posts/story/${child.key}`] = null;
    });

    if (Object.keys(updates).length > 0) {
      await db.ref().update(updates);
    }
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  LIMPAR RATE LIMITS EXPIRADOS
// ══════════════════════════════════════════════════════════════════════════════

export const purgarRateLimitsExpirados = onSchedule(
  { schedule: "every 6 hours", region: REGION },
  async () => {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;

    // OTIMIZAÇÃO: Lê UIDs de UserIndex em vez do nó RateLimits inteiro.
    const indexSnap = await db.ref("UserIndex").get();
    if (!indexSnap.exists()) return;

    const uids = Object.keys(indexSnap.val() as Record<string, unknown>);
    let totalPurged = 0;

    for (let i = 0; i < uids.length; i += 30) {
      const batch = uids.slice(i, i + 30);
      await Promise.all(
        batch.map(async (uid) => {
          try {
            const snap = await db.ref(`RateLimits/${uid}`).get();
            if (!snap.exists()) return;

            const updates: Record<string, null> = {};
            snap.forEach((actionNode) => {
              const val = actionNode.val() as Record<string, unknown>;
              const windowStart = val.window_start as number ?? 0;
              if (windowStart > 0 && windowStart < cutoff) {
                updates[`RateLimits/${uid}/${actionNode.key}`] = null;
                totalPurged++;
              }
            });

            if (Object.keys(updates).length > 0) {
              await db.ref().update(updates);
            }
          } catch (err) {
            console.warn(`[purgarRateLimitsExpirados] Erro uid=${uid}:`, err);
          }
        })
      );
    }

    if (totalPurged > 0) {
      console.log(`[purgarRateLimitsExpirados] ${totalPurged} rate limits removidos`);
    }
  }
);

// ══════════════════════════════════════════════════════════════════════════════
//  LIMPAR CONTADORES DIÁRIOS ANTIGOS
// ══════════════════════════════════════════════════════════════════════════════

export const limparContadoresAntigos = onSchedule(
  { schedule: "every 24 hours", region: REGION },
  async () => {
    const hoje = new Date().toISOString().slice(0, 10);

    // OTIMIZAÇÃO: Lê UIDs de UserIndex e processa por usuário.
    const indexSnap = await db.ref("UserIndex").get();
    if (!indexSnap.exists()) return;

    const uids = Object.keys(indexSnap.val() as Record<string, unknown>);
    let totalPurged = 0;

    for (let i = 0; i < uids.length; i += 30) {
      const batch = uids.slice(i, i + 30);
      await Promise.all(
        batch.map(async (uid) => {
          try {
            const snap = await db.ref(`NotificationsDailyCount/${uid}`).get();
            if (!snap.exists()) return;

            const updates: Record<string, null> = {};
            snap.forEach((typeNode) => {
              const val = typeNode.val() as Record<string, unknown>;
              const date = val.date as string ?? "";
              if (date && date !== hoje) {
                updates[`NotificationsDailyCount/${uid}/${typeNode.key}`] = null;
                totalPurged++;
              }
            });

            if (Object.keys(updates).length > 0) {
              await db.ref().update(updates);
            }
          } catch (err) {
            console.warn(`[limparContadoresAntigos] Erro uid=${uid}:`, err);
          }
        })
      );
    }

    if (totalPurged > 0) {
      console.log(`[limparContadoresAntigos] ${totalPurged} contadores removidos`);
    }
  }
);
